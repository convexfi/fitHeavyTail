% Description: This demo code compares the convergence of four algorithms for
%              robust joint mean-covariance estimation proposed in ref. [1]. 
%              The K dimensional N samples are generated from a
%              multivariate t-distribution with DoF 3, mean 1, and
%              covariance matrix R with elements R_ij = beta^|i-j|.
 
% Reference:   [1] Ying Sun, Prabhu Babu, and Daniel P. Palomar,
%                  "Regularized Robust Estimation of Mean and Covariance Matrix Under Heavy-Tailed Distributions,"
%                  IEEE Trans. on Signal Processing, vol. 63, no. 12, pp. 3096-3109, June 2015.
% Link:        http://www.danielppalomar.com/publications.html
% Author:      Ying Sun  
% Date:        02/19/2017 
% Note:        Please contact <sun578@purdue.edu> for any problem related
%              to this code.


clear
clc

beta = 0.8;
tol = 1e-5;

ratio = .8;
K = 100;
rho_alpha = .3;
rho_gamma = .2;
repts = 1;
nu = 3;

for i = 1:repts
    
    N = ceil(K*ratio);
    c = beta.^abs([1:K]'-1);
    r = beta.^abs(1-[1:K]);
    R = toeplitz(c,r);
    mu = ones(K,1);
    
    mu = randn(K,1);
    tmp = randn(K);
    R = tmp*tmp';
    R = R/trace(R);
    
    % generate sample
    x = mvtrnd(eye(K),nu,N)';
    x = sqrtm(R)*x;
    x = kron(ones(1,N),mu)+x;
    
    alpha = N/2*(1./rho_alpha-1);
    gamma = N/2*(1./rho_gamma-1);
    
    T = eye(K)/K;
    mu_t = 0.5*ones(K,1);
    
    mu_init = zeros(K,1);
    R_init = eye(K);
    % algorithm 1: majorize R mu together
    
    
    [mu1,R1,f1] = Joint_Mean_Cov(x,mu_t,T,gamma,alpha,mu_init,R_init,tol);
    
    % algorithm 2: majorize R then mu
    
    [mu2,R2,f2] = Cov_Mean(x,mu_t,T,gamma,alpha,mu_init,R_init,tol);
    
    % algorithm 3: majorize mu then R
    [mu3,R3,f3] = Mean_Cov(x,mu_t,T,gamma,alpha,mu_init,R_init,tol);
    
    % algorithm 4  accelerated MM
    
    [mu4,R4,f4] = Acc_Mean_Cov(x,mu_t,T,gamma,alpha,mu_init,R_init,tol);
end

loglog(1:length(f1),f1,'b-',1:length(f2),f2,'r--',1:length(f3),f3,'m:',1:length(f4),f4,'k-.')
xlabel('Iterations');
ylabel('Objective function value')
legend('MM','Block MM (first R then \mu)','Block MM (first \mu then R)','Accelerated MM')
subfig = axes('Position',[0.275 0.63 0.16 0.24]);
loglog(subfig,5:length(f1),f1(5:end),'b-',5:length(f2),f2(5:end),'r--',5:length(f3),f3(5:end),'m:',5:length(f4),f4(5:end),'k-.')
%axis([1 15 800 2400])
