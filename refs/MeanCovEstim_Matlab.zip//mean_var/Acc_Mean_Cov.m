% Description: This code implements robust joint mean-covariance estimation
%              using Alg. 4 [1].

% Input:
%   x:         K-by-N data matrix
%   mu_t:      shrinkage target of mean
%   T:         shrinkage target of covariance
%   gamma:     shrinkage penalty parameter of mean
%   alpha:     shrinkage penalty parameter of covariance
%   mu_init:   initial value of mean
%   R_init:    initial value of covariance matrix
%   tol:       convergence tolerance
%
% Output:
%   mu:        K-by-1 vector. Estimated mean vector
%   Rn:        K-by-K matrix. Estimated covariance matrix
%
% Reference:   [1] Ying Sun, Prabhu Babu, and Daniel P. Palomar,
%                  "Regularized Robust Estimation of Mean and Covariance Matrix Under Heavy-Tailed Distributions,"
%                  IEEE Trans. on Signal Processing, vol. 63, no. 12, pp. 3096-3109, June 2015.
% Link:        http://www.danielppalomar.com/publications.html
% Author:      Ying Sun
% Date:        04/06/2017
% Note:        Please contact <sun578@purdue.edu> for any problem related
%              to this code.

function [mu,R,f] = Acc_Mean_Cov(x,mu_t,T,gamma,alpha,mu_init,R_init,tol)
[K N] = size(x);
if(isempty(mu_init))
    mu = zeros(K,1);
else
    mu = mu_init;
end
if(isempty(R_init))
    R = eye(K);
else
    R = R_init;
end

MAXITER = 1e4; % maximum allowed number of iterations

R_n = R; mu_n = mu;

iter = 1;
f(iter)=(N/2+alpha)*log(det(R))...
    +(K+1)/2*sum(log((1+diag((x-kron(ones(1,N),mu))'*inv(R)*(x-kron(ones(1,N),mu))))))...
    +alpha*K*log(trace(inv(R)*T))...
    +gamma*log(1+(mu-mu_t)'*inv(R)*(mu-mu_t));

Converge = 0;
while(~Converge)
    iter = iter + 1;
    wi = 1./(1+diag((x-kron(ones(1,N),mu_n))'*inv(R_n)*(x-kron(ones(1,N),mu_n))));
    wmu = 1/(1+(mu_n-mu_t)'*inv(R_n)*(mu_n-mu_t));
    % update mu
    mu = ((K+1)*sum(x*diag(wi),2)+2*gamma*wmu*mu_t)/((K+1)*sum(wi)+2*gamma*wmu);
    Converge = norm(mu - mu_n,'fro')<tol;
    mu_n = mu;
    % update R
    R = (K+1)/(N+2*alpha)*(x-kron(ones(1,N),mu))*diag(wi)*(x-kron(ones(1,N),mu))'...
        +(2*alpha*K*T)/((N+2*alpha)*trace(inv(R_n)*T))...
        +(2*gamma)/(N+2*alpha)*wmu*(mu_t-mu)*(mu_t-mu)';
    
    zeta = ((K+1)/2*sum(wi)+gamma*wmu)/(N/2+gamma);
    R = R/zeta;
    
    Converge = Converge & norm(R-R_n,'fro')<tol;
    
    R_n = R;
    f(iter)=(N/2+alpha)*log(det(R))...
        +(K+1)/2*sum(log((1+diag((x-kron(ones(1,N),mu))'*inv(R)*(x-kron(ones(1,N),mu))))))...
        +alpha*K*log(trace(inv(R)*T))...
        +gamma*log(1+(mu-mu_t)'*inv(R)*(mu-mu_t));
    if(iter > MAXITER)
        warning('Maximum number of iterations reached, consider increasing the limit');
        return;
    end
end
end