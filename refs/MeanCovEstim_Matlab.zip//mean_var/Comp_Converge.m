% This file compares the convergence speed of different proposed algorithms

clear
clc

beta = 0.8;
tol = 1e-5;

ratio = .8;
K = 100;
rho_alpha = .3;
rho_gamma = .2;
repts = 1;
nu = 3;
for i = 1:repts
    
    N = ceil(K*ratio);
    c = beta.^abs([1:K]'-1);
    r = beta.^abs(1-[1:K]);
    R = toeplitz(c,r);
    mu = ones(K,1);
    
    mu = randn(K,1);
    tmp = randn(K);
    R = tmp*tmp';
    R = R/trace(R);
   
    % generate sample
    x = mvtrnd(eye(K),nu,N)';
    %x = mvnrnd(zeros(K,1),eye(K),N)';
    x = sqrtm(R)*x;
    x = kron(ones(1,N),mu)+x;
    
    alpha = N/2*(1./rho_alpha-1);
    gamma = N/2*(1./rho_gamma-1);
    
    T = eye(K)/K;
    mut = 0.5*ones(K,1);
    
    % algorithm 1: majorize R mu together
    
     muint = zeros(K,1);
    Rint = eye(K);
    R1 = Rint;
    R1n = R1;
    mu1 = muint;
    mu1n = mu1;
    
    itr1 = 1;
    f1(itr1)=(N/2+alpha)*log(det(R1n))+(K+1)/2*sum(log((1+diag((x-kron(ones(1,N),mu1))'*inv(R1n)*(x-kron(ones(1,N),mu1))))))+alpha*K*log(trace(inv(R1n)*T))+gamma*log(1+(mu1-mut)'*inv(R1n)*(mu1-mut));
    Converge = 0;
    while(~Converge)
        itr1 = itr1+1;
        mu1n = mu1;
        wi1 = 1./(1+diag((x-kron(ones(1,N),mu1n))'*inv(R1n)*(x-kron(ones(1,N),mu1n))));
        wmu = 1/(1+(mu1n-mut)'*inv(R1n)*(mu1n-mut));
        % update mu
        mu1 = ((K+1)*sum(x*diag(wi1),2)+2*gamma*wmu*mut)/((K+1)*sum(wi1)+2*gamma*wmu);
        Converge = norm(mu1-mu1n,Inf)<tol;
        % update R
        R1 = (K+1)/(N+2*alpha)*(x-kron(ones(1,N),mu1))*diag(wi1)*(x-kron(ones(1,N),mu1))'...
            +(2*alpha*K*T)/((N+2*alpha)*trace(inv(R1n)*T))...
            +(2*gamma)/(N+2*alpha)*wmu*(mut-mu1)*(mut-mu1)';
        Converge = Converge & norm(R1-R1n,Inf)<tol;
        R1n = R1;
        f1(itr1)=(N/2+alpha)*log(det(R1n))+(K+1)/2*sum(log((1+diag((x-kron(ones(1,N),mu1))'*inv(R1n)*(x-kron(ones(1,N),mu1))))))+alpha*K*log(trace(inv(R1n)*T))...
            +gamma*log(1+(mu1-mut)'*inv(R1n)*(mu1-mut));
    end
    
    
    
    % algorithm 2: majorize R then mu
    
    R2 = Rint;
    R2n = R2;
    mu2 = muint;
    
    itr2 = 1;
    f2(itr2)=(N/2+alpha)*log(det(R2n))+(K+1)/2*sum(log((1+diag((x-kron(ones(1,N),mu2))'*inv(R2n)*(x-kron(ones(1,N),mu2))))))+alpha*K*log(trace(inv(R2n)*T))...
        +gamma*log(1+(mu2-mut)'*inv(R2n)*(mu2-mut));
    Converge = 0;
    while(~Converge)
        itr2 = itr2+1;
        mu2n = mu2;
        wi2 = 1./(1+diag((x-kron(ones(1,N),mu2n))'*inv(R2n)*(x-kron(ones(1,N),mu2n))));
        wmu = 1/(1+(mu2n-mut)'*inv(R2n)*(mu2n-mut));
        % update R
        R2 = (K+1)/(N+2*alpha)*(x-kron(ones(1,N),mu2n))*diag(wi2)*(x-kron(ones(1,N),mu2n))'...
            +(2*alpha*K*T)/((N+2*alpha)*trace(inv(R2n)*T))...
            +(2*gamma)/(N+2*alpha)*wmu*(mut-mu2n)*(mut-mu2n)';
        Converge = norm(R2-R2n,Inf)<tol;
        R2n = R2;
        % renew weight
        wi2 = 1./(1+diag((x-kron(ones(1,N),mu2n))'*inv(R2n)*(x-kron(ones(1,N),mu2n))));
        wmu = 1/(1+(mu2n-mut)'*inv(R2n)*(mu2n-mut));
        % update mu
        mu2 = ((K+1)*sum(x*diag(wi2),2)+2*gamma*wmu*mut)/((K+1)*sum(wi2)+2*gamma*wmu);
        Converge = Converge & norm(mu2-mu2n,Inf)<tol;
        f2(itr2)=(N/2+alpha)*log(det(R2n))+(K+1)/2*sum(log((1+diag((x-kron(ones(1,N),mu2))'*inv(R2n)*(x-kron(ones(1,N),mu2))))))+alpha*K*log(trace(inv(R2n)*T))...
            +gamma*log(1+(mu2-mut)'*inv(R2n)*(mu2-mut));
        %plot(itr,(1+alpha)*log(det(R3n))+(K+1)/N*sum(log((1+diag((x-kron(ones(1,N),mu3))'*inv(R3n)*(x-kron(ones(1,N),mu3))))))+alpha*K*log(trace(inv(R3n)*T)),'ro')
    end
    
    % algorithm 3: majorize mu then R
    
    R3 = Rint;
    R3n = R3;
    mu3 = muint;
    mu3n = mu3;
    
    itr3 = 1;
    f3(itr3)=(N/2+alpha)*log(det(R3))+(K+1)/2*sum(log((1+diag((x-kron(ones(1,N),mu3n))'*inv(R3)*(x-kron(ones(1,N),mu3n))))))+alpha*K*log(trace(inv(R3)*T))...
        +gamma*log(1+(mu3n-mut)'*inv(R3)*(mu3n-mut));
    Converge = 0;
    while(~Converge)
        itr3 = itr3+1;
        R3n = R3;
        wi3 = 1./(1+diag((x-kron(ones(1,N),mu3n))'*inv(R3n)*(x-kron(ones(1,N),mu3n))));
        wmu = 1/(1+(mu3n-mut)'*inv(R3n)*(mu3n-mut));
        % update mu
        mu3 = ((K+1)*sum(x*diag(wi3),2)+gamma*2*wmu*mut)/((K+1)*sum(wi3)+gamma*2*wmu);
        Converge = norm(mu3-mu3n,Inf)<tol;
        mu3n = mu3;
        % renew weight
        wi3 = 1./(1+diag((x-kron(ones(1,N),mu3n))'*inv(R3n)*(x-kron(ones(1,N),mu3n))));
        wmu = 1/(1+(mu3n-mut)'*inv(R3n)*(mu3n-mut));
        % update R
        
        R3 = (K+1)/(N+2*alpha)*(x-kron(ones(1,N),mu3n))*diag(wi3)*(x-kron(ones(1,N),mu3n))'...
            +(2*alpha*K*T)/((N+2*alpha)*trace(inv(R3n)*T))...
            +(2*gamma)/(N+2*alpha)*wmu*(mut-mu3n)*(mut-mu3n)';
        Converge = Converge & norm(R3-R3n,Inf)<tol;
        f3(itr3)=(N/2+alpha)*log(det(R3))+(K+1)/2*sum(log((1+diag((x-kron(ones(1,N),mu3n))'*inv(R3)*(x-kron(ones(1,N),mu3n))))))+alpha*K*log(trace(inv(R3)*T))...
            +gamma*log(1+(mu3n-mut)'*inv(R3)*(mu3n-mut));
        
    end
    
    % algorithm 4  accelerated MM
    itr4 = 1;
    R4 = Rint;
    R4n = R4;
    mu4 = muint;
    mu4n = mu4;
    f4(itr4)=(N/2+alpha)*log(det(R4n))+(K+1)/2*sum(log((1+diag((x-kron(ones(1,N),mu4))'*inv(R4n)*(x-kron(ones(1,N),mu4))))))+alpha*K*log(trace(inv(R4n)*T))+gamma*log(1+(mu4-mut)'*inv(R4n)*(mu4-mut));
    Converge = 0;
    while(~Converge)
        
        itr4 = itr4+1;
        
        wi4 = 1./(1+diag((x-kron(ones(1,N),mu4n))'*inv(R4n)*(x-kron(ones(1,N),mu4n))));
        wmu = 1/(1+(mu4n-mut)'*inv(R4n)*(mu4n-mut));
        % update mu
        mu4 = ((K+1)*sum(x*diag(wi4),2)+2*gamma*wmu*mut)/((K+1)*sum(wi4)+2*gamma*wmu);
        Converge = norm(mu4-mu4n,'fro')<tol;
        mu4n = mu4;
        % update R
        R4 = (K+1)/(N+2*alpha)*(x-kron(ones(1,N),mu4))*diag(wi4)*(x-kron(ones(1,N),mu4))'...
            +(2*alpha*K*T)/((N+2*alpha)*trace(inv(R4n)*T))...
            +(2*gamma)/(N+2*alpha)*wmu*(mut-mu4)*(mut-mu4)';
        %
        %
        %                 f1(itr1)=(N/2+alpha)*log(det(R1))+(K+1)/2*sum(log((1+diag((x-kron(ones(1,N),mu1))'*inv(R1)*(x-kron(ones(1,N),mu1))))))+alpha*K*log(trace(inv(R1)*T))...
        %                     +gamma*log(1+(mu1-mut)'*inv(R1)*(mu1-mut));
        %                                     hold on
        %                                      plot(itr1,f1(itr1),'r.');
        %                                      itr1 = itr1 + 1;
        zeta = ((K+1)/2*sum(wi4)+gamma*wmu)/(N/2+gamma);
        R4 = R4/zeta;
        
        Converge = Converge & norm(R4-R4n,'fro')<tol;
        
        %(log(det(R1))-log(det(R1n)))*(zeta-1)
        %                                      trace(R1n*inv(R1))-K
        %                                      trace(R1*inv(R1n))-K
        R4n = R4;
        f4(itr4)=(N/2+alpha)*log(det(R4n))+(K+1)/2*sum(log((1+diag((x-kron(ones(1,N),mu4))'*inv(R4n)*(x-kron(ones(1,N),mu4))))))+alpha*K*log(trace(inv(R4n)*T))...
            +gamma*log(1+(mu4-mut)'*inv(R4n)*(mu4-mut));
%                                             hold on
%                                              plot(itr4,f4(itr4),'r.');
                                        
    end
    
end

loglog(1:itr1,f1,'b-',1:itr2,f2,'r--',1:itr3,f3,'m:',1:itr4,f4,'k-.')
xlabel('Iterations');
ylabel('Objective function value')
legend('MM','Block MM (first R then \mu)','Block MM (first \mu then R)','Accelerated MM')
subfig = axes('Position',[0.275 0.63 0.16 0.24]);
loglog(subfig,5:itr1,f1(5:end),'b-',5:itr2,f2(5:end),'r--',5:itr3,f3(5:end),'m:',5:itr4,f4(5:end),'k-.')
%axis([1 15 800 2400])
